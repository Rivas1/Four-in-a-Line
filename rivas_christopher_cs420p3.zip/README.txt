1. Unzip folder and there should be 5 files:  1.AI.java, 
					      2.Board.Java, 
					      3.FourInALine.java, 
					      4.Position.java, 
				              5.UserInterface.java

2. Open command prompt and navigate to directory where you unzipped the files.

3. Compile all 5 files: javac AI.java
			javac Board.java
			javac FourInALine.java
			javac Position.java
			javac UserInterface.java

4. Now run program by typing: java FourInALine